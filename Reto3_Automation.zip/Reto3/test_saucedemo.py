import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

URL = "https://www.saucedemo.com/"

@pytest.fixture(scope="module")
def driver():
    print("\n" + "=" * 75)
    print(" [SETUP] Iniciando navegador Chrome para Suite de Automatización...")
    print("=" * 75)
    options = webdriver.ChromeOptions()
    options.page_load_strategy = "eager"
    options.add_argument("--start-maximized")
    options.add_argument("--incognito")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_experimental_option("prefs", {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False
    })

    driver = webdriver.Chrome(options=options)
    yield driver
    print("\n" + "=" * 75)
    print(" [TEARDOWN] Cerrando navegador y finalizando pruebas.")
    print("=" * 75)
    driver.quit()


def login_estandar(driver, wait):
    """Función auxiliar para autenticar al usuario en precondiciones."""
    driver.get(URL)
    user_input = wait.until(EC.visibility_of_element_located((By.ID, "user-name")))
    user_input.clear()
    user_input.send_keys("standard_user")
    pass_input = driver.find_element(By.ID, "password")
    pass_input.clear()
    pass_input.send_keys("secret_sauce")
    driver.find_element(By.ID, "login-button").click()


# =========================================================================
# CP-01: Inicio de sesión exitoso con credenciales válidas
# =========================================================================
def test_cp01_login_exitoso(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-01: Inicio de sesión exitoso con credenciales válidas")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Navegar al sitio web: https://www.saucedemo.com/")
    driver.get(URL)
    
    print("  [Paso 2] Ingresar usuario válido: 'standard_user'")
    wait.until(EC.visibility_of_element_located((By.ID, "user-name"))).send_keys("standard_user")
    
    print("  [Paso 3] Ingresar contraseña válida: 'secret_sauce'")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    
    print("  [Paso 4] Hacer clic en el botón 'Login'")
    driver.find_element(By.ID, "login-button").click()

    print("  [Validación] Verificar redirección al inventario (/inventory.html)")
    assert "inventory.html" in driver.current_url
    print("  [RESULTADO CP-01] PASSED - Acceso concedido correctamente.")


# =========================================================================
# CP-02: Restricción de acceso para usuario bloqueado
# =========================================================================
def test_cp02_usuario_bloqueado(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-02: Restricción de acceso para usuario bloqueado")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Navegar a la pantalla de Login")
    driver.get(URL)
    
    print("  [Paso 2] Ingresar usuario bloqueado: 'locked_out_user'")
    wait.until(EC.visibility_of_element_located((By.ID, "user-name"))).send_keys("locked_out_user")
    
    print("  [Paso 3] Ingresar contraseña: 'secret_sauce'")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    
    print("  [Paso 4] Hacer clic en el botón 'Login'")
    driver.find_element(By.ID, "login-button").click()

    error = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "[data-test='error']"))).text
    print(f"  [Validación] Mensaje de bloqueo obtenido: '{error}'")
    assert "Sorry, this user has been locked out" in error
    print("  [RESULTADO CP-02] PASSED - Usuario bloqueado rechazado exitosamente.")


# =========================================================================
# CP-03: Flujo E2E - Registro completo de datos del usuario y compra exitosa
# =========================================================================
def test_cp03_registro_completo_y_compra_exitosa(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-03: Flujo E2E - Registro completo de datos del usuario y compra exitosa")
    print("---------------------------------------------------------------------------")
    
    print("  [Precondición] Iniciar sesión con 'standard_user'")
    login_estandar(driver, wait)

    print("  [Paso 1] Agregar producto 'Sauce Labs Backpack' al carrito")
    botones_mochila = driver.find_elements(By.ID, "add-to-cart-sauce-labs-backpack")
    if botones_mochila:
        botones_mochila[0].click()

    print("  [Paso 2] Ir al carrito de compras y hacer clic en 'Checkout'")
    driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()
    wait.until(EC.element_to_be_clickable((By.ID, "checkout"))).click()

    print("  [Paso 3] Completar formulario de registro: First Name='Carlos Dario', Last Name='Lara Garcia', Zip='07000'")
    wait.until(EC.visibility_of_element_located((By.ID, "first-name"))).send_keys("Carlos Dario")
    driver.find_element(By.ID, "last-name").send_keys("Lara Garcia")
    driver.find_element(By.ID, "postal-code").send_keys("07000")

    print("  [Paso 4] Hacer clic en 'Continue' y posteriormente en 'Finish'")
    driver.find_element(By.ID, "continue").click()
    wait.until(EC.element_to_be_clickable((By.ID, "finish"))).click()

    mensaje = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, "complete-header"))).text
    print(f"  [Validación] Confirmación en pantalla: '{mensaje}'")
    assert mensaje == "Thank you for your order!"
    print("  [RESULTADO CP-03] PASSED - Registro completo y orden finalizada.")


# =========================================================================
# CP-04: Validar obligatoriedad del campo "First Name" en registro
# =========================================================================
def test_cp04_registro_first_name_vacio(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-04: Validar obligatoriedad del campo 'First Name' en registro")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Ubicarse en el formulario de registro (/checkout-step-one.html)")
    driver.get("https://www.saucedemo.com/checkout-step-one.html")

    print("  [Paso 2] Dejar 'First Name' vacío e ingresar Last Name='Lara Garcia' y Zip='07000'")
    wait.until(EC.visibility_of_element_located((By.ID, "last-name"))).send_keys("Lara Garcia")
    driver.find_element(By.ID, "postal-code").send_keys("07000")

    print("  [Paso 3] Hacer clic en 'Continue'")
    driver.find_element(By.ID, "continue").click()

    error = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "[data-test='error']"))).text
    print(f"  [Validación] Alerta mostrada: '{error}'")
    assert "Error: First Name is required" in error
    print("  [RESULTADO CP-04] PASSED - Campo First Name validado como obligatorio.")


# =========================================================================
# CP-05: Validar obligatoriedad del campo "Last Name" en registro
# =========================================================================
def test_cp05_registro_last_name_vacio(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-05: Validar obligatoriedad del campo 'Last Name' en registro")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Ubicarse en el formulario de registro (/checkout-step-one.html)")
    driver.get("https://www.saucedemo.com/checkout-step-one.html")

    print("  [Paso 2] Ingresar First Name='Carlos Dario', dejar 'Last Name' vacío e ingresar Zip='07000'")
    wait.until(EC.visibility_of_element_located((By.ID, "first-name"))).send_keys("Carlos Dario")
    driver.find_element(By.ID, "postal-code").send_keys("07000")

    print("  [Paso 3] Hacer clic en 'Continue'")
    driver.find_element(By.ID, "continue").click()

    error = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "[data-test='error']"))).text
    print(f"  [Validación] Alerta mostrada: '{error}'")
    assert "Error: Last Name is required" in error
    print("  [RESULTADO CP-05] PASSED - Campo Last Name validado como obligatorio.")


# =========================================================================
# CP-06: Validar obligatoriedad del campo "Postal Code" en registro
# =========================================================================
def test_cp06_registro_postal_code_vacio(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-06: Validar obligatoriedad del campo 'Postal Code' en registro")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Ubicarse en el formulario de registro (/checkout-step-one.html)")
    driver.get("https://www.saucedemo.com/checkout-step-one.html")

    print("  [Paso 2] Ingresar First Name='Carlos Dario', Last Name='Lara Garcia' y dejar 'Postal Code' vacío")
    wait.until(EC.visibility_of_element_located((By.ID, "first-name"))).send_keys("Carlos Dario")
    driver.find_element(By.ID, "last-name").send_keys("Lara Garcia")

    print("  [Paso 3] Hacer clic en 'Continue'")
    driver.find_element(By.ID, "continue").click()

    error = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "[data-test='error']"))).text
    print(f"  [Validación] Alerta mostrada: '{error}'")
    assert "Error: Postal Code is required" in error
    print("  [RESULTADO CP-06] PASSED - Campo Postal Code validado como obligatorio.")


# =========================================================================
# CP-07: Validación de cálculo de total con impuestos y cierre de sesión
# =========================================================================
def test_cp07_calculo_total_y_logout(driver):
    wait = WebDriverWait(driver, 15)
    print("\n\n---------------------------------------------------------------------------")
    print("CP-07: Validación de cálculo de total con impuestos y cierre de sesión")
    print("---------------------------------------------------------------------------")
    
    print("  [Paso 1] Ir al catálogo y asegurar producto 'Sauce Labs Backpack' ($29.99) en el carrito")
    driver.get("https://www.saucedemo.com/inventory.html")
    botones_mochila = driver.find_elements(By.ID, "add-to-cart-sauce-labs-backpack")
    if botones_mochila:
        botones_mochila[0].click()

    print("  [Paso 2] Completar el registro en Checkout para avanzar al resumen (/checkout-step-two.html)")
    driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()
    wait.until(EC.element_to_be_clickable((By.ID, "checkout"))).click()
    wait.until(EC.visibility_of_element_located((By.ID, "first-name"))).send_keys("Carlos Dario")
    driver.find_element(By.ID, "last-name").send_keys("Lara Garcia")
    driver.find_element(By.ID, "postal-code").send_keys("07000")
    driver.find_element(By.ID, "continue").click()

    total_text = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, "summary_total_label"))).text
    print(f"  [Paso 3] Verificar cálculo de total con impuestos (Item $29.99 + Tax $2.40): '{total_text}'")
    assert "$32.39" in total_text

    print("  [Paso 4] Abrir menú lateral y hacer clic en 'Logout'")
    driver.find_element(By.ID, "react-burger-menu-btn").click()
    wait.until(EC.element_to_be_clickable((By.ID, "logout_sidebar_link"))).click()

    print("  [Validación] Confirmar regreso a la pantalla de Login")
    assert wait.until(EC.visibility_of_element_located((By.ID, "login-button"))).is_displayed()
    print("  [RESULTADO CP-07] PASSED - Cálculo correcto y sesión cerrada con éxito.")


if __name__ == "__main__":
    pytest.main(["-v", "-s", __file__])